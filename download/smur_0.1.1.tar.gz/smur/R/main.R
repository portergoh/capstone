#-----------------------------------------------------------------------#
# Capstone project for Data Analytics Specialist R Certification Program
#-----------------------------------------------------------------------#
# Tutor: Prof Roh Sungjong (SMU Academy)
# Student: Brian Sum
# Student: Goh Khee Teck
# Date of completion:
#
# Data are collected from both sites:
# - https://condo.singaporeexpats.com
# - https://www.ura.gov.sg/maps/api/#private-non-landed-residential-properties-median-rentals-by-name
#-----------------------------------------------------------------------#

#-----------------------------------------------------------------------#
# Instruction for running this R script:
#-----------------------------------------------------------------------#
# Please setup your working dir before continue
#
# You may choose to run only a portion of the main code to get the
# results of your analysis
#-----------------------------------------------------------------------#
working_dir <- "/Users/kheeteck/data/gcs/dasr/capstone/smur/R"

# Accesskey is only valid for 1 year from 25 Nov 2018
ura_access_key <- "6117f3d4-81e2-4b3e-9ff9-2640045d2b5a"
setwd(working_dir)
getwd()

# Load all the require packages and functions from github
source("https://raw.githubusercontent.com/portergoh/capstone/master/smur/R/smur_install.R")
smur_install()

#-----------------------------------------------------------------------#
# Main program:
# - Data Collection & Tidy
# - Data Visualisation
# - Data Transformation
# - Data Modeling
#-----------------------------------------------------------------------#





